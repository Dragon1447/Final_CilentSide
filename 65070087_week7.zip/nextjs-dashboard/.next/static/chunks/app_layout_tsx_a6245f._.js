(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_a6245f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_a6245f._.js",
  "chunks": [
    "static/chunks/[root of the server]__81e440._.css",
    "static/chunks/node_modules_next_dist_23a2cf._.js"
  ],
  "source": "dynamic"
});
