(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_page_tsx_0c0782._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_page_tsx_0c0782._.js",
  "chunks": [
    "static/chunks/_f52f42._.js"
  ],
  "source": "dynamic"
});
