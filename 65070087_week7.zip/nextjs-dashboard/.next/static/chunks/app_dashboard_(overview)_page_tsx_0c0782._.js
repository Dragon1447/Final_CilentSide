(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_dashboard_(overview)_page_tsx_0c0782._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_dashboard_(overview)_page_tsx_0c0782._.js",
  "chunks": [
    "static/chunks/_ffa52d._.js"
  ],
  "source": "dynamic"
});
