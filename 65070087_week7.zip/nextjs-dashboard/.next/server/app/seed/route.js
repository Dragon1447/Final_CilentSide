const CHUNK_PUBLIC_PATH = "server/app/seed/route.js";
const runtime = require("../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/node_modules_75939d._.js");
runtime.loadChunk("server/chunks/[root of the server]__099e2c._.js");
runtime.loadChunk("server/chunks/_8ffc04._.js");
runtime.getOrInstantiateRuntimeModule("[project]/.next-internal/server/app/seed/route/actions.js [app-rsc] (ecmascript)", CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/seed/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
