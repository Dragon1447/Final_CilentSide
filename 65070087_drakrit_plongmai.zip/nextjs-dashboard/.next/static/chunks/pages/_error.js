__turbopack_load_page_chunks__("/_error", [
  "static/chunks/[root of the server]__1e1522._.js",
  "static/chunks/545c3_react-dom_1c85ba._.js",
  "static/chunks/node_modules__pnpm_ca0bcc._.js",
  "static/chunks/[root of the server]__2e1cf5._.js",
  "static/chunks/pages__error_5771e1._.js",
  "static/chunks/pages__error_43a0f5._.js"
])
