import Link from 'next/link';

export default function Home() {
  return (
    <div>
      {/* Navbar */}
      <nav className="flex justify-between items-center bg-gray-800 px-5 py-4 sticky top-0 z-[1000]">
        <div className="text-2xl font-bold text-white ">Try Tailwind</div>
        <div className="flex">
          <Link className="text-white mx-3 text-base hover:text-[#cbd5e0]" href='/'>Home</Link>
          <Link className="text-white mx-3 text-base hover:text-[#cbd5e0]" href='/features'>Features</Link>
          <Link className="text-white mx-3 text-base hover:text-[#cbd5e0]" href='/pricing'>Pricing</Link>
          <Link className="text-white mx-3 text-base hover:text-[#cbd5e0]" href='/contact'>Contact</Link>
          <Link className="text-white mx-3 text-base hover:text-[#cbd5e0]" href="/"></Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-[url('/images/hero-bg.jpg')] bg-cover bg-center text-white text-center py-[100px] px-5">
        <h1 className="text-[3.5rem] mb-5">Build Amazing Websites</h1>
        <p className="text-xl mb-[30px]">
          We provide the best tools to create stunning and functional websites.
        </p>
        <button className="bg-[#4299e1] text-white border-0 px-6 py-3 text-base rounded hover:bg-[#2b6cb0]">
          Get Started
        </button>
      </section>

      {/* Features Section */}
      <section className="max-w-[1200px] mx-auto p-5">
        <div className="flex justify-between gap-5 mt-[60px]">
          <div className="bg-white p-8 rounded-lg shadow w-1/3 text-center">
            <img
              src="/images/icn-easy.png"
              alt="Feature 1"
              className="w-[100px] mx-auto mb-5"
            />
            <h2 className="text-xl mb-2">Easy to Use</h2>
            <p className="text-base text-gray-600">
              Our platform is designed to be user-friendly for everyone.
            </p>
          </div>
          <div className="bg-white p-8 rounded-lg shadow w-1/3 text-center">
            <img
              src="/images/icn-responsive.png"
              alt="Feature 2"
              className="w-[100px] mx-auto mb-5"
            />
            <h2 className="text-xl mb-2">Responsive Design</h2>
            <p className="text-base text-gray-600">
              Your website will look great on any device.
            </p>
          </div>
          <div className="bg-white p-8 rounded-lg shadow w-1/3 text-center">
            <img
              src="/images/icn-performance.png"
              alt="Feature 3"
              className="w-[100px] mx-auto mb-5"
            />
            <h2 className="text-xl mb-2">Fast Performance</h2>
            <p className="text-base text-gray-600">
              Optimized for speed and performance.
            </p>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="max-w-[1200px] mx-auto p-5 mt-20 text-center">
        <h2 className="text-2xl mb-10">What Our Users Say</h2>
        <div className="flex justify-between gap-5">
          <div className="bg-white p-5 rounded-lg shadow w-1/3">
            <img
              src="/images/user1.png"
              alt="User 1"
              className="w-[100px] h-[100px] rounded-full mx-auto mb-4"
            />
            <p className="text-base text-gray-600 mb-4">
              "This platform is amazing! It helped me build my website in no time."
            </p>
            <h3 className="text-lg mb-1 font-semibold">John Doe</h3>
            <span className="text-sm text-gray-500">Web Developer</span>
          </div>
          <div className="bg-white p-5 rounded-lg shadow w-1/3">
            <img
              src="/images/user2.png"
              alt="User 2"
              className="w-[100px] h-[100px] rounded-full mx-auto mb-4"
            />
            <p className="text-base text-gray-600 mb-4">
              "I love how easy it is to use. Highly recommended!"
            </p>
            <h3 className="text-lg mb-1 font-semibold">Jane Smith</h3>
            <span className="text-sm text-gray-500">Designer</span>
          </div>
          <div className="bg-white p-5 rounded-lg shadow w-1/3">
            <img
              src="/images/user3.png"
              alt="User 3"
              className="w-[100px] h-[100px] rounded-full mx-auto mb-4"
            />
            <p className="text-base text-gray-600 mb-4">
              "The performance is outstanding. My website loads super fast!"
            </p>
            <h3 className="text-lg mb-1 font-semibold">Mike Johnson</h3>
            <span className="text-sm text-gray-500">Entrepreneur</span>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="max-w-[1200px] mx-auto p-5 mt-20 text-center">
        <h2 className="text-2xl mb-10">Pricing Plans</h2>
        <div className="flex justify-between gap-5">
          <div className="bg-white p-8 rounded-lg shadow w-1/3">
            <h3 className="text-xl mb-5">Basic</h3>
            <p className="text-base text-gray-600 mb-5">
              Perfect for small projects
            </p>
            <div className="text-3xl font-bold text-[#4299e1] mb-5">$10/month</div>
            <button className="bg-[#4299e1] text-white border-0 px-5 py-2 text-base rounded hover:bg-[#2b6cb0]">
              Choose Plan
            </button>
          </div>
          <div className="bg-white p-8 rounded-lg shadow w-1/3">
            <h3 className="text-xl mb-5">Pro</h3>
            <p className="text-base text-gray-600 mb-5">
              Great for growing businesses
            </p>
            <div className="text-3xl font-bold text-[#4299e1] mb-5">$25/month</div>
            <button className="bg-[#4299e1] text-white border-0 px-5 py-2 text-base rounded hover:bg-[#2b6cb0]">
              Choose Plan
            </button>
          </div>
          <div className="bg-white p-8 rounded-lg shadow w-1/3">
            <h3 className="text-xl mb-5">Enterprise</h3>
            <p className="text-base text-gray-600 mb-5">
              For large-scale projects
            </p>
            <div className="text-3xl font-bold text-[#4299e1] mb-5">$50/month</div>
            <button className="bg-[#4299e1] text-white border-0 px-5 py-2 text-base rounded hover:bg-[#2b6cb0]">
              Choose Plan
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#2d3748] text-white text-center p-10 mt-20">
        <div className="mb-5">
          <a href="#" className="text-white no-underline mx-2 text-xl hover:text-[#cbd5e0]">
            Facebook
          </a>
          <a href="#" className="text-white no-underline mx-2 text-xl hover:text-[#cbd5e0]">
            Twitter
          </a>
          <a href="#" className="text-white no-underline mx-2 text-xl hover:text-[#cbd5e0]">
            LinkedIn
          </a>
        </div>
        <p className="mt-5 text-sm text-[#cbd5e0]">
          &copy; 2025 Try Tailwind. All rights reserved.
        </p>
      </footer>
    </div>
  );
}
